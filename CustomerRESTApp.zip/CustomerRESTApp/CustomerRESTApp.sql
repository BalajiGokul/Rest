create table customer (customerId int,customerName varchar(25),location varchar(25));
insert into customer values(1,'Balaji','Salem');
insert into customer values(2,'Vignesh','Chennai');
insert into customer values(3,'GobiKannan','Theni');
insert into customer values(4,'Mufazil','Thuthukudi');
insert into customer values(5,'Ashik','Karur');
select * from customer;