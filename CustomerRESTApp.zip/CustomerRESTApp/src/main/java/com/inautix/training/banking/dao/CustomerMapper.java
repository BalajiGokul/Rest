package com.inautix.training.banking.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.inautix.training.banking.domain.Customer;
import com.inautix.training.banking.domain.Customer;

public class CustomerMapper implements RowMapper<Customer>{

	public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
		Customer customer = new Customer();
		customer.setCustomerId(rs.getInt(1));
		customer.setCustomerName(rs.getString("customerName"));
		customer.setLocation(rs.getString("location"));
	      return customer;
	   }	
}
