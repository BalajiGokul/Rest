package com.inautix.training.banking.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.inautix.training.banking.domain.Customer;

public class CustomerDAO {
	
	private DataSource dataSource;
	   private JdbcTemplate jdbcTemplateObject;
	   
	   public void setDataSource(DataSource dataSource) {
	      this.dataSource = dataSource;
	      this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	   }
	
	public void createCustomer(Customer customer){
		
      String sql ="insert into customer values ("+customer.getCustomerId()+",'"+customer.getCustomerName()+"','"+customer.getLocation()+"')";
      System.out.println("sql "+sql);			

      jdbcTemplateObject.update(sql);
			
			
   }
	
	
	public void updateCustomer(Customer customer){
		
		String sql="update customer  set customerName='"+customer.getCustomerName()+"', location='" +customer.getLocation()+"' where customerId=" + customer.getCustomerId();
		 System.out.println("sql "+sql);	
		 
		 jdbcTemplateObject.update(sql);
	}
	
			
public void deleteCustomer(int customerId){
		
		String sql="delete from customer where customerId="+customerId;
		 System.out.println("sql "+sql);	
		 
		 jdbcTemplateObject.update(sql);
	}

		
	
	public List getAllCustomer(){
		
		List customerList = null;
		String sql="select * from customer";
		customerList = jdbcTemplateObject.query(sql, new Object[]{}, new CustomerMapper());
	      System.out.println("inside dao getAllCustomer");
	    return 	customerList;
	    
	  }
		
			
	

 public Customer getCustomerDetails(int customerId) {
	 
String sql = "select * from customer where customerId= ?";

Customer customer=jdbcTemplateObject.queryForObject(sql, new Object[]{customerId}, new CustomerMapper());

return customer;
}
}
